# Replace these with your actual credentials
GMGN_API_KEY = "your_gmgn_api_key"
TELEGRAM_BOT_TOKEN = "your_telegram_bot_token"
TELEGRAM_CHAT_ID = "your_chat_id"  # Can be user ID or group/channel ID