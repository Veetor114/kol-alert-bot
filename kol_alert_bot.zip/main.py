import time
import json
from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
from utils import fetch_gmgn_data, send_telegram_alert, load_wallets, filter_transactions

CHECK_INTERVAL = 300  # 5 minutes

def main():
    print("KOL Alert Bot started...")
    wallets = load_wallets()
    while True:
        try:
            data = fetch_gmgn_data()
            alerts = filter_transactions(data, wallets)
            for alert in alerts:
                send_telegram_alert(alert)
        except Exception as e:
            print(f"Error: {e}")
        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    main()