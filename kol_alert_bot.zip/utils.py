import requests
import json
from config import GMGN_API_KEY, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID

def load_wallets():
    with open("wallets.json", "r") as f:
        return json.load(f)

def fetch_gmgn_data():
    url = "https://api.gmgn.ai/v1/transactions"
    headers = {"Authorization": f"Bearer {GMGN_API_KEY}"}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"GMGN API error: {response.status_code}")

def filter_transactions(data, wallets):
    alerts = []
    tier_a = set(wallets["tier_a"])
    tier_b = set(wallets["tier_b"])
    all_wallets = tier_a.union(tier_b)

    token_activity = {}

    for tx in data.get("transactions", []):
        wallet = tx.get("wallet")
        token = tx.get("token_symbol")
        token_address = tx.get("token_address", "")
        token_age = tx.get("token_age", "")  # Expected to be a readable string like '2h', '1d', etc.
        volume = float(tx.get("usd_value", 0))
        market_cap = float(tx.get("market_cap", 0))

        if wallet not in all_wallets or volume < 2500 or market_cap < 9000:
            continue

        if token not in token_activity:
            token_activity[token] = {
                "wallets": set(),
                "tier_a_hits": 0,
                "volume": 0,
                "market_cap": market_cap,
                "token_address": token_address,
                "token_age": token_age
            }

        token_activity[token]["wallets"].add(wallet)
        if wallet in tier_a:
            token_activity[token]["tier_a_hits"] += 1
        token_activity[token]["volume"] += volume

    for token, info in token_activity.items():
        if len(info["wallets"]) >= 5:
            token_addr = info["token_address"]
            token_age = info.get("token_age", "N/A")
            chart_link = f"https://dexscreener.com/solana/{token_addr}" if token_addr else "N/A"
            alert_msg = (
                f"*Token:* ${token}\n"
                f"*Age:* {token_age}\n"
                f"*Volume:* ${info['volume']:.0f}\n"
                f"*Market Cap:* ${info['market_cap']:.0f}\n"
                f"*Buyers:* {len(info['wallets'])} (Tier A: {info['tier_a_hits']})\n\n"
                f"[Chart]({chart_link}) | [GMGN](https://gmgn.ai) | [Axiom Pro](https://t.me/Axiom_Pro_Bot)"
            )
            alerts.append(alert_msg)

    return alerts

def send_telegram_alert(message):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
        "parse_mode": "Markdown"
    }
    requests.post(url, json=payload)